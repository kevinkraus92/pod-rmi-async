#!/bin/bash

java  -cp 'lib/jars/*' "itba.pod.server.Server" $*

